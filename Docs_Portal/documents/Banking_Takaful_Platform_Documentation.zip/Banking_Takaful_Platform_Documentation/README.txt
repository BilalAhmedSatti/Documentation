MULTI-TENANT DIGITAL BANKING & REMITTANCE PLATFORM  +  TAKAFUL (ISLAMIC INSURANCE)
Complete engineering documentation set
Blueprint v3.1 · Status: DESIGN / BLUEPRINT STAGE — no code built yet
Generated 29 July 2026 · Confidential — Internal Use

Launch markets: Pakistan → UAE → Saudi Arabia
Stack: NestJS 10 / TypeScript strict by default; Java 21 / Spring Boot 3.3 for the
calculation core only (Ledger 04, Pricing 10, FX library 17)

--------------------------------------------------------------------------------
01_Blueprint_Specifications  (29 documents, 00–28)
--------------------------------------------------------------------------------
  00  Master Architecture Blueprint
  01  Technology Stack & Decision Record
  02–13  Domain & platform services
         02 Identity/KYC/KYB · 03 Screening & AML · 04 Ledger (JVM)
         05 Payments & Remittance · 06 Wallets & Accounts · 07 Card Issuing (optional)
         08 Compliance Reporting · 09 Reconciliation · 10 Pricing/Billing (JVM)
         11 Developer Platform/Gateway/BFF · 12 Tenant Registry & Control Plane
         13 Notification
  14–22  Adapters
         14 Persistence · 15 Screening provider · 16 eKYC provider
         17 FX Rate (JVM library) · 18 Core Banking Host · 19 Payout Rail
         20 Card Processor · 21 Notification/Messaging · 22 IdP/OIDC
  23  Documentation Index & Build Order
  24–26  New shared adapters
         24 Credit/Risk Bureau · 25 Country Tax Computation · 26 E-Signature/Consent
  27  Repository, Branching & Development Readiness
  28  Repository Catalog & Specification

--------------------------------------------------------------------------------
02_Design_Companions  (30 files)
--------------------------------------------------------------------------------
  Engineering design.md companion for each specification: code-level interfaces,
  DDL excerpts, sequence diagrams, test gates.
  UPDATED for ADR-0002: 04_ledger, 10_pricing, 17_fx_adapter.

--------------------------------------------------------------------------------
03_Feature_Specifications  (24 documents)
--------------------------------------------------------------------------------
  One standalone feature spec per service/adapter. Each contains: overview,
  in/out of scope, MoSCoW feature catalogue, functional and non-functional
  requirements, data owned, interfaces, dependencies, risks & controls.
  UPDATED for ADR-0002: 04_Ledger_Feature_Spec (new FX provenance feature area).

--------------------------------------------------------------------------------
04_Decisions_ADR  (1 record)
--------------------------------------------------------------------------------
  ADR-0002  FX conversion: booking, rate provenance, and statement reporting
            Closes six previously-unspecified decisions (D1–D7):
            rate provenance (journals.quote_id), statement fields
            (journals.display_meta), spread currency, conversion journal shape,
            FX rate scale-8, no rate lookup on the posting path, and pilot scope.
  NOTE: ADR-0001 (repository & branching strategy) is recorded inside Document 27.

--------------------------------------------------------------------------------
05_Plans_and_Milestones  (3 documents)
--------------------------------------------------------------------------------
  29  Development Plan, Sequencing & Milestones — the programme plan: squads,
      critical path, 9 phases with parallel streams, sprint timeline, gates M0–M8
  Ledger_04_Milestone_Plan       — Ledger milestones L0–L5 with exit criteria
  Ledger_04_One_Page_Plan        — single-page overview + features by milestone

--------------------------------------------------------------------------------
06_Presentations  (3 files)
--------------------------------------------------------------------------------
  Platform_Architecture_Review.pptx                  banking engineering review (13 slides)
  Shared_Adapter_Platform_Banking_Takaful.pptx       shared-adapter deck (16 slides)
  Presenter_Script_Roman_Urdu.docx                   slide-by-slide Roman Urdu script

--------------------------------------------------------------------------------
WHERE TO START
--------------------------------------------------------------------------------
  1. Read 00 (Master Architecture) and 01 (Stack decision).
  2. Read 29 (Development Plan) — it tells you what to build in what order.
  3. Execute Document 27 §8 (day-one runbook) to stand up the GitHub org and CI.
  4. Build the foundation trio first: Control Plane (12), Persistence (14), OIDC (22).
  5. Start regulator/provider certification (NADRA, Raast, SBP) in the SAME week
     as Sprint 0 — engineering can be recovered with people; certification lead
     time cannot.

  Eight shared adapters serve BOTH applications: Identity/KYC (16),
  Screening/AML (15), Credit Bureau (24), Payment Rails (19), Country Tax (25),
  E-Signature/Consent (26), Notification (13/21), Control Plane (12).
